var class_dot_z_lib_1_1_codec_base =
[
    [ "CodecBase", "class_dot_z_lib_1_1_codec_base.html#a1e372f5061c8f7c16a55bc41c55ebfa5", null ],
    [ "Add", "class_dot_z_lib_1_1_codec_base.html#a9131ff23312ada67dbf58f428d562de4", null ],
    [ "Add", "class_dot_z_lib_1_1_codec_base.html#ab01e6ad1d9c5b05745dd9e487aaa40ee", null ],
    [ "CleanUp", "class_dot_z_lib_1_1_codec_base.html#aa0ded075105c5cf6f5f0d61928c90ca6", null ],
    [ "copyInput", "class_dot_z_lib_1_1_codec_base.html#a8c827f091195356490e7f8b69e0546a7", null ],
    [ "Dispose", "class_dot_z_lib_1_1_codec_base.html#ab4bdcee97631d9e80d2bceb01d01f368", null ],
    [ "Finish", "class_dot_z_lib_1_1_codec_base.html#abab96cb01a9b983452a31777e3a1e633", null ],
    [ "OnDataAvailable", "class_dot_z_lib_1_1_codec_base.html#a5c697195bc017ae951858e7c8948f9ae", null ],
    [ "resetOutput", "class_dot_z_lib_1_1_codec_base.html#a801b625073b21aeaab52ebf9e96dd9c9", null ],
    [ "setChecksum", "class_dot_z_lib_1_1_codec_base.html#a5dfa2dddf3ac857652af7fd8e3d2034d", null ],
    [ "_isDisposed", "class_dot_z_lib_1_1_codec_base.html#a9aa2d3961669aad672e43946c25ae24b", null ],
    [ "kBufferSize", "class_dot_z_lib_1_1_codec_base.html#a6cf60968f7eaa921e5a8108e0ebcb880", null ],
    [ "Checksum", "class_dot_z_lib_1_1_codec_base.html#aac848293ff53082bb60cb561daa6fd6b", null ],
    [ "DataAvailable", "class_dot_z_lib_1_1_codec_base.html#a985cf58f6ed5cfeeb9fd8c34a7c052d4", null ]
];