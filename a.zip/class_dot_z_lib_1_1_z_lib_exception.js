var class_dot_z_lib_1_1_z_lib_exception =
[
    [ "ZLibException", "class_dot_z_lib_1_1_z_lib_exception.html#a6a413e419130b98ef8a443a74b2f8ded", null ],
    [ "ZLibException", "class_dot_z_lib_1_1_z_lib_exception.html#af8dd9c725ef7bd7b2d2042e827ce9fb7", null ]
];