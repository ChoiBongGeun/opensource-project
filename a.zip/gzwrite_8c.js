var gzwrite_8c =
[
    [ "gz_comp", "gzwrite_8c.html#a578bb1f539c1df875e6ebe887663d425", null ],
    [ "gz_init", "gzwrite_8c.html#a3fb2532b5691da6f2120dc0c8df10df3", null ],
    [ "gz_write", "gzwrite_8c.html#af73b41937514710ee55fca44e1e38417", null ],
    [ "gz_zero", "gzwrite_8c.html#a6fad277f0035b7b2048f6187bb03692c", null ],
    [ "gzclose_w", "gzwrite_8c.html#a6f657e5b498bef603821cdf41c8375d4", null ],
    [ "gzflush", "gzwrite_8c.html#a6b70d5783d03b12adfd369bd9b7394a2", null ],
    [ "gzfwrite", "gzwrite_8c.html#abbc1f2c9217d3f887a2038216a38893f", null ],
    [ "gzprintf", "gzwrite_8c.html#a23cb6f01c1de1f861e22091d0ca092ef", null ],
    [ "gzputc", "gzwrite_8c.html#a37f7621e057bd71abdbe2f2480b69935", null ],
    [ "gzputs", "gzwrite_8c.html#a2760b9a721dd2950d101046d9b57c461", null ],
    [ "gzsetparams", "gzwrite_8c.html#a20e49f282c69489d3733593736212876", null ],
    [ "gzwrite", "gzwrite_8c.html#a93323ef1288f105db8a89e80f2764d3b", null ],
    [ "OF", "gzwrite_8c.html#ab2bb6a74d8a540f213c47cd34dab32c5", null ],
    [ "OF", "gzwrite_8c.html#a81445df3df03a8472757a7ce99eabf56", null ],
    [ "OF", "gzwrite_8c.html#a5eb0ac16312161458394c125d5d13a41", null ],
    [ "OF", "gzwrite_8c.html#a68015f621080b08d02c4404681d17585", null ]
];