var structtdefl__output__buffer =
[
    [ "m_capacity", "structtdefl__output__buffer.html#ab0705ebff551ebede28640ada5a9d2ab", null ],
    [ "m_expandable", "structtdefl__output__buffer.html#a26e5da3f933edc1a218afbe7838e9d22", null ],
    [ "m_pBuf", "structtdefl__output__buffer.html#a60119e1ddcb4fb92149189bed7cb8250", null ],
    [ "m_size", "structtdefl__output__buffer.html#ab506aa434be983761db4cca43d2ebc9e", null ]
];