var test_8c =
[
    [ "buffer_t", "structbuffer__t.html", "structbuffer__t" ],
    [ "CRC32DATA1", "test_8c.html#a5216d8b5182825de8227cd54075e39d9", null ],
    [ "CRC32DATA2", "test_8c.html#acb2c5b369fa7bbecd9bc9f77c34e2d34", null ],
    [ "MZ_FILE_STAT", "test_8c.html#a06857ce8d288f462c7a2c5ded5eeea7c", null ],
    [ "MZ_FILE_STAT_STRUCT", "test_8c.html#abbb4323f24a8e32a583c0b1b7e6820c9", null ],
    [ "RFILE", "test_8c.html#af69318ea4c03a0128fb3a04cfec4e4ca", null ],
    [ "RMODE", "test_8c.html#a779d0d1c39fa4f9ef5104a43f909b820", null ],
    [ "TESTDATA1", "test_8c.html#adaf6a77833a7088acd6ba18d7466ac59", null ],
    [ "TESTDATA2", "test_8c.html#a32bbf61a3a6cafc997ccb8f449ba8f4c", null ],
    [ "UNUSED", "test_8c.html#a86d500a34c624c2cae56bc25a31b12f3", null ],
    [ "WFILE", "test_8c.html#aa46368d8dc5683fc05fde329f4c69532", null ],
    [ "WMODE", "test_8c.html#acbeeb93d9c8c821a3ee60f61cfeb46cf", null ],
    [ "XFILE", "test_8c.html#ac24922843682a0947847063be3180b12", null ],
    [ "XMODE", "test_8c.html#a40a507a9d967e3131aea8424ad7b097f", null ],
    [ "ZIPNAME", "test_8c.html#ac060043c99e6bd4ed8e311aa404406cf", null ],
    [ "main", "test_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ]
];