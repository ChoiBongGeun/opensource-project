/*
@ @licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2017 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "zlib", "index.html", [
    [ "네임스페이스", "namespaces.html", [
      [ "네임스페이스 목록", "namespaces.html", "namespaces_dup" ],
      [ "네임스페이스 멤버", "namespacemembers.html", [
        [ "모두", "namespacemembers.html", null ],
        [ "함수", "namespacemembers_func.html", null ],
        [ "열거형 타입", "namespacemembers_enum.html", null ]
      ] ]
    ] ],
    [ "클래스", "annotated.html", [
      [ "클래스 목록", "annotated.html", "annotated_dup" ],
      [ "클래스 색인", "classes.html", null ],
      [ "클래스 계통도", "hierarchy.html", "hierarchy" ],
      [ "클래스 멤버", "functions.html", [
        [ "모두", "functions.html", "functions_dup" ],
        [ "함수", "functions_func.html", null ],
        [ "변수", "functions_vars.html", "functions_vars" ],
        [ "속성", "functions_prop.html", null ],
        [ "이벤트", "functions_evnt.html", null ],
        [ "관련된 함수들", "functions_rela.html", null ]
      ] ]
    ] ],
    [ "파일들", "files.html", [
      [ "파일 목록", "files.html", "files_dup" ],
      [ "파일 멤버", "globals.html", [
        [ "모두", "globals.html", "globals_dup" ],
        [ "함수", "globals_func.html", "globals_func" ],
        [ "변수", "globals_vars.html", null ],
        [ "타입정의", "globals_type.html", null ],
        [ "열거형 타입", "globals_enum.html", null ],
        [ "열거형 멤버", "globals_eval.html", null ],
        [ "매크로", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_2zfstream_8h.html",
"crc32_8h_source.html",
"globals_defs_v.html",
"infback9_8h.html",
"ioapi_8h.html#a4c4816968d9e57a9e916bafe96dd7157",
"structgz__header__s.html#a397959afc459da7e296c676a3d4c1915",
"structtm__unz__s.html#ac5a6bf08a4c5db8ae2243d4f0c35b192",
"untgz_8c.html#ac2f730c538c61e5eccfbc9b41a180c8d",
"zip_8h.html#a7d0ef3b50756549bc6ffcfe4dd5e9dd9"
];

var SYNCONMSG = '패널 동기화를 비활성화하기 위해 클릭하십시오';
var SYNCOFFMSG = '패널 동기화를 활성화하기 위해 클릭하십시오';