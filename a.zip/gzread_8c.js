var gzread_8c =
[
    [ "gz_avail", "gzread_8c.html#a880d9d0c2827714cd40d8ba7f3637294", null ],
    [ "gz_decomp", "gzread_8c.html#a4b2cb72f18826fd5410e1cbdd9cf3941", null ],
    [ "gz_fetch", "gzread_8c.html#a221059506dd52a3dc6fa990f0e191ba8", null ],
    [ "gz_load", "gzread_8c.html#af7f3ad614b7059314f1673da8950df3f", null ],
    [ "gz_look", "gzread_8c.html#a2335993758928a1328423a4c3cd8f5a5", null ],
    [ "gz_read", "gzread_8c.html#a2e7c20ac97b2f2d7cd21c3e0399999b5", null ],
    [ "gz_skip", "gzread_8c.html#aa3f15e560c3c56fc5d845afd2c5c0b56", null ],
    [ "gzclose_r", "gzread_8c.html#a74218c3c6e5eddf23a9f3cb2e08f9637", null ],
    [ "gzdirect", "gzread_8c.html#a1f049b9405deb0e7dad1fe97ed4dd8c2", null ],
    [ "gzfread", "gzread_8c.html#acebeb254a3cecff218bdd52bcd90d7cf", null ],
    [ "gzgetc", "gzread_8c.html#a1e9f6a517ed1e04c3765fe24153fb639", null ],
    [ "gzgetc_", "gzread_8c.html#a3bcd38c3aaf6694dadfc7c29d1ae7ddb", null ],
    [ "gzgets", "gzread_8c.html#a72d5c31ad36987a6a3252d56f1e98664", null ],
    [ "gzread", "gzread_8c.html#a2d0d971b446b67bbc4261fa5fef622bd", null ],
    [ "gzungetc", "gzread_8c.html#a0b81c1a6e144a3cc5cd97a26688fed69", null ],
    [ "OF", "gzread_8c.html#a6ccd5c126388fb6a0fd12130b905049c", null ],
    [ "OF", "gzread_8c.html#acb1e2f2d49607baf1d4ec50e02b2554b", null ],
    [ "OF", "gzread_8c.html#aaab7957fa61f365b48678cf454644175", null ],
    [ "OF", "gzread_8c.html#a14b72776da634bc8d347c5b883cec9a8", null ]
];