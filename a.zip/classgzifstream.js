var classgzifstream =
[
    [ "gzifstream", "classgzifstream.html#a6fa19ba2a1eeaeab5f0a408082bc2edd", null ],
    [ "gzifstream", "classgzifstream.html#a56e464903ee517fb3377f9d8a2977694", null ],
    [ "gzifstream", "classgzifstream.html#ab1380a28c963c7b3b85dc63d0d11cc1a", null ],
    [ "~gzifstream", "classgzifstream.html#a61a1c9344f4d50c2ae7b3e555a509385", null ],
    [ "gzifstream", "classgzifstream.html#a6fa19ba2a1eeaeab5f0a408082bc2edd", null ],
    [ "gzifstream", "classgzifstream.html#a90f6e0eea83b7ce3c64f755b51b5b011", null ],
    [ "gzifstream", "classgzifstream.html#aa5ab9dcc3ab35bffe781f4c49239826e", null ],
    [ "attach", "classgzifstream.html#a24aff901c395acbdaddb7878f4ddb7aa", null ],
    [ "close", "classgzifstream.html#a073fadd9dc90195c47a6ae2d863c8ace", null ],
    [ "is_open", "classgzifstream.html#a8e9de13b311b698ef0ccc276b71c7941", null ],
    [ "open", "classgzifstream.html#a8105f9300d36dafbe8b10c204583f5a1", null ],
    [ "rdbuf", "classgzifstream.html#a1c5a0ab4f99f8d8e3406af7bfd82b133", null ]
];