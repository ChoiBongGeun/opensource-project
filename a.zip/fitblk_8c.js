var fitblk_8c =
[
    [ "EXCESS", "fitblk_8c.html#a5ce8e34830796387c57019ed0548fef1", null ],
    [ "local", "fitblk_8c.html#a08023ea6765c99d60a6a3840cd07156e", null ],
    [ "MARGIN", "fitblk_8c.html#ab05a798afd72aac947f417e1dab73c87", null ],
    [ "RAWLEN", "fitblk_8c.html#a9d6c180d0b6eb924cb9ad755de8d6584", null ],
    [ "main", "fitblk_8c.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "partcompress", "fitblk_8c.html#a5b3701500d649b362de46d1fc90553c9", null ],
    [ "quit", "fitblk_8c.html#adfe304d693a8e4bb8744c7405b0889db", null ],
    [ "recompress", "fitblk_8c.html#a2197932367c707dc96d43197714db5a1", null ]
];