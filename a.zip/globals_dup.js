var globals_dup =
[
    [ "_", "globals.html", null ],
    [ "a", "globals_a.html", null ],
    [ "b", "globals_b.html", null ],
    [ "c", "globals_c.html", null ],
    [ "d", "globals_d.html", null ],
    [ "f", "globals_f.html", null ],
    [ "h", "globals_h.html", null ],
    [ "i", "globals_i.html", null ],
    [ "m", "globals_m.html", null ],
    [ "r", "globals_r.html", null ],
    [ "s", "globals_s.html", null ],
    [ "t", "globals_t.html", null ],
    [ "u", "globals_u.html", null ],
    [ "v", "globals_v.html", null ],
    [ "w", "globals_w.html", null ],
    [ "x", "globals_x.html", null ],
    [ "z", "globals_z.html", null ]
];