var puff_8h =
[
    [ "NIL", "puff_8h.html#a263efce0e5cda1d387a1a43f94715445", null ],
    [ "puff", "puff_8h.html#a37210080eeb63cf5200b5fd61ca89d06", null ]
];