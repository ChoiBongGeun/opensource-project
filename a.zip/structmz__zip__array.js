var structmz__zip__array =
[
    [ "m_capacity", "structmz__zip__array.html#abb5fb11f941f23713d9a8ef20930bf68", null ],
    [ "m_element_size", "structmz__zip__array.html#ac3eb7acc1c233ed3c53db813d7d00692", null ],
    [ "m_p", "structmz__zip__array.html#a8054ffa9a3da062a1d7528b124a8b651", null ],
    [ "m_size", "structmz__zip__array.html#a00858a0bceae00064e3e0b25bebfd939", null ]
];