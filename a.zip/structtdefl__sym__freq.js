var structtdefl__sym__freq =
[
    [ "m_key", "structtdefl__sym__freq.html#ab3e92f7d87da65857f18f8b8fb0a6ecb", null ],
    [ "m_sym_index", "structtdefl__sym__freq.html#a17b56e7162419d3ea5fe175d3f1c855e", null ]
];