var interface_dot_z_lib_1_1_codec =
[
    [ "Add", "interface_dot_z_lib_1_1_codec.html#aa40d0820bd95f098b3e7d8e707e7a536", null ],
    [ "Add", "interface_dot_z_lib_1_1_codec.html#a137234d0c6fa6981ca8b602340e79dbc", null ],
    [ "Finish", "interface_dot_z_lib_1_1_codec.html#af12b887d445dcbc5e7c11b3aa000aa27", null ],
    [ "Checksum", "interface_dot_z_lib_1_1_codec.html#aa5f968120138390af2648c956d4355cb", null ],
    [ "DataAvailable", "interface_dot_z_lib_1_1_codec.html#a54b5cd5685e1256fcb0cb6ead5c3e5b5", null ]
];