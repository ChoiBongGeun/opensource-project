var gzappend_8c =
[
    [ "file", "structfile.html", "structfile" ],
    [ "CHUNK", "gzappend_8c.html#a25022864dfc8ec428e7128282e57b136", null ],
    [ "DSIZE", "gzappend_8c.html#a5961fe5ed1cedbe60fcbdc97623f0ac2", null ],
    [ "LGCHUNK", "gzappend_8c.html#a9ff81f68cbd2c773a6c9e8a72bd9e5e6", null ],
    [ "local", "gzappend_8c.html#a08023ea6765c99d60a6a3840cd07156e", null ],
    [ "read1", "gzappend_8c.html#a5fddaa7746819fd99e8fc5e8f91706dc", null ],
    [ "bye", "gzappend_8c.html#a355a7b66c6a35db52db69dfb55e40a8b", null ],
    [ "gcd", "gzappend_8c.html#aab2f4ce94c55eee75c730ef29348b822", null ],
    [ "gzheader", "gzappend_8c.html#a4324fdde25721c9213ba77c86bc25c89", null ],
    [ "gzscan", "gzappend_8c.html#ac867b637486dd9902d2939130cc26f5d", null ],
    [ "gztack", "gzappend_8c.html#a00052bd14d0258425de7561880408955", null ],
    [ "main", "gzappend_8c.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "read4", "gzappend_8c.html#a7a80796bb5b7f9891fcb2a57d7aff0bf", null ],
    [ "readin", "gzappend_8c.html#a1cb1b33dccef1abf6de9d873cc45c234", null ],
    [ "readmore", "gzappend_8c.html#adc077b2ce84e52cf6cf5a9a435371257", null ],
    [ "rotate", "gzappend_8c.html#a4f13e4c742e47380cfb3aa6744ff89a7", null ],
    [ "skip", "gzappend_8c.html#ab3ed01aa0272a6da17923faad217d3bd", null ]
];