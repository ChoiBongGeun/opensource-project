var test__miniz_8c =
[
    [ "uint", "test__miniz_8c.html#a91ad9478d81a7aaf2593e8d9c3d06a14", null ],
    [ "uint16", "test__miniz_8c.html#a05f6b0ae8f6a6e135b0e290c25fe0e4e", null ],
    [ "uint8", "test__miniz_8c.html#adde6aaee8457bee49c2a92621fe22b79", null ],
    [ "main", "test__miniz_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ]
];