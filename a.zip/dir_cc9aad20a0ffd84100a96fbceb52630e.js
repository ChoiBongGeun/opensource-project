var dir_cc9aad20a0ffd84100a96fbceb52630e =
[
    [ "test.c", "test_8c.html", "test_8c" ],
    [ "test_miniz.c", "test__miniz_8c.html", "test__miniz_8c" ]
];