var structtinfl__huff__table =
[
    [ "m_code_size", "structtinfl__huff__table.html#a31f719d4829db3d6646139d5249094cb", null ],
    [ "m_look_up", "structtinfl__huff__table.html#a51b707504c86547f166bc557d7ce4f84", null ],
    [ "m_tree", "structtinfl__huff__table.html#a1208fe7e128f00188f99ba6f51fa9af6", null ]
];