var structmz__zip__writer__add__state =
[
    [ "m_comp_size", "structmz__zip__writer__add__state.html#a4736843d8fbef3a1d323451bb29ae3cd", null ],
    [ "m_cur_archive_file_ofs", "structmz__zip__writer__add__state.html#a305f9fa7f47b583ee53b8ee0401edd9e", null ],
    [ "m_pZip", "structmz__zip__writer__add__state.html#a8beb0e578862314a35cc724aeb95e709", null ]
];