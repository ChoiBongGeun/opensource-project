var dir_c660bc6e334d67866164d50ef7b4a828 =
[
    [ "AssemblyInfo.cs", "_assembly_info_8cs.html", null ],
    [ "ChecksumImpl.cs", "_checksum_impl_8cs.html", [
      [ "ChecksumGeneratorBase", "class_dot_z_lib_1_1_checksum_generator_base.html", "class_dot_z_lib_1_1_checksum_generator_base" ],
      [ "CRC32Checksum", "class_dot_z_lib_1_1_c_r_c32_checksum.html", "class_dot_z_lib_1_1_c_r_c32_checksum" ],
      [ "AdlerChecksum", "class_dot_z_lib_1_1_adler_checksum.html", "class_dot_z_lib_1_1_adler_checksum" ]
    ] ],
    [ "CircularBuffer.cs", "_circular_buffer_8cs.html", null ],
    [ "CodecBase.cs", "_codec_base_8cs.html", [
      [ "CodecBase", "class_dot_z_lib_1_1_codec_base.html", "class_dot_z_lib_1_1_codec_base" ]
    ] ],
    [ "Deflater.cs", "_deflater_8cs.html", [
      [ "Deflater", "class_dot_z_lib_1_1_deflater.html", "class_dot_z_lib_1_1_deflater" ]
    ] ],
    [ "DotZLib.cs", "_dot_z_lib_8cs.html", "_dot_z_lib_8cs" ],
    [ "GZipStream.cs", "_g_zip_stream_8cs.html", [
      [ "GZipStream", "class_dot_z_lib_1_1_g_zip_stream.html", "class_dot_z_lib_1_1_g_zip_stream" ]
    ] ],
    [ "Inflater.cs", "_inflater_8cs.html", [
      [ "Inflater", "class_dot_z_lib_1_1_inflater.html", "class_dot_z_lib_1_1_inflater" ]
    ] ],
    [ "UnitTests.cs", "_unit_tests_8cs.html", null ]
];