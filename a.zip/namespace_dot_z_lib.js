var namespace_dot_z_lib =
[
    [ "AdlerChecksum", "class_dot_z_lib_1_1_adler_checksum.html", "class_dot_z_lib_1_1_adler_checksum" ],
    [ "ChecksumGenerator", "interface_dot_z_lib_1_1_checksum_generator.html", "interface_dot_z_lib_1_1_checksum_generator" ],
    [ "ChecksumGeneratorBase", "class_dot_z_lib_1_1_checksum_generator_base.html", "class_dot_z_lib_1_1_checksum_generator_base" ],
    [ "Codec", "interface_dot_z_lib_1_1_codec.html", "interface_dot_z_lib_1_1_codec" ],
    [ "CodecBase", "class_dot_z_lib_1_1_codec_base.html", "class_dot_z_lib_1_1_codec_base" ],
    [ "CRC32Checksum", "class_dot_z_lib_1_1_c_r_c32_checksum.html", "class_dot_z_lib_1_1_c_r_c32_checksum" ],
    [ "Deflater", "class_dot_z_lib_1_1_deflater.html", "class_dot_z_lib_1_1_deflater" ],
    [ "GZipStream", "class_dot_z_lib_1_1_g_zip_stream.html", "class_dot_z_lib_1_1_g_zip_stream" ],
    [ "Inflater", "class_dot_z_lib_1_1_inflater.html", "class_dot_z_lib_1_1_inflater" ],
    [ "Info", "class_dot_z_lib_1_1_info.html", "class_dot_z_lib_1_1_info" ],
    [ "ZLibException", "class_dot_z_lib_1_1_z_lib_exception.html", "class_dot_z_lib_1_1_z_lib_exception" ]
];