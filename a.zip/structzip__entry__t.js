var structzip__entry__t =
[
    [ "comp", "structzip__entry__t.html#a79675cd05faed3a9ea895d5808399dc0", null ],
    [ "comp_size", "structzip__entry__t.html#a28e5cc79882ca7b963d7bd39aa393266", null ],
    [ "external_attr", "structzip__entry__t.html#a9a3ac29f98a4722d7612f8b6e40485e5", null ],
    [ "header", "structzip__entry__t.html#aee5b6c5e6c344349895ea2588f32e75a", null ],
    [ "header_offset", "structzip__entry__t.html#aaddf5f588ad62f3a8cb61c06fd7596c4", null ],
    [ "index", "structzip__entry__t.html#a5b8e3cd72f3d5ef90d2e660f6ad38687", null ],
    [ "m_time", "structzip__entry__t.html#a8a4a9b16e0f0c369b1f7fc8c242527e0", null ],
    [ "method", "structzip__entry__t.html#a4fa192bffbdb183c8b772ead61ee825c", null ],
    [ "name", "structzip__entry__t.html#a6e2873a477844002286fed23f74d1e82", null ],
    [ "offset", "structzip__entry__t.html#aa41c0267e22c55b948c696cc8d789b6c", null ],
    [ "state", "structzip__entry__t.html#a324592620d55a44fe6b7178cf5062d05", null ],
    [ "uncomp_crc32", "structzip__entry__t.html#a9198d6cc15b29592d9135dfe15fb08df", null ],
    [ "uncomp_size", "structzip__entry__t.html#aed12cc7f61192b0b0f73ddfe49442b23", null ]
];