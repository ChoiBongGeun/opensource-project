var structzip__t =
[
    [ "archive", "structzip__t.html#ac491c25b4d8afa85e4a41272d0089add", null ],
    [ "entry", "structzip__t.html#aee479cc5e2106c5953c9c65851910ab9", null ],
    [ "level", "structzip__t.html#a95f8b4b0c8d33d3e198dccc8f3f17114", null ]
];