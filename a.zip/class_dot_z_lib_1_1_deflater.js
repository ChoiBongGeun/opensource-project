var class_dot_z_lib_1_1_deflater =
[
    [ "Deflater", "class_dot_z_lib_1_1_deflater.html#a3af92869710011e866633c2186c7cab1", null ],
    [ "Add", "class_dot_z_lib_1_1_deflater.html#a2db95e3ca07e562df0652ed1ad8d0c4d", null ],
    [ "CleanUp", "class_dot_z_lib_1_1_deflater.html#af06ac29d92dbe5d6198b8fa906476e05", null ],
    [ "Finish", "class_dot_z_lib_1_1_deflater.html#a84507769a20a13c2ff48cfcef8f5c13b", null ]
];