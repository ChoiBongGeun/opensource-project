var structmz__zip__archive__tag =
[
    [ "m_archive_size", "structmz__zip__archive__tag.html#af5117c04008ecd572508f136876db80e", null ],
    [ "m_central_directory_file_ofs", "structmz__zip__archive__tag.html#ab249c8c383a7e7941787d96c19f4398e", null ],
    [ "m_file_offset_alignment", "structmz__zip__archive__tag.html#a65668944eaf9a001aec06191f9b348de", null ],
    [ "m_pAlloc", "structmz__zip__archive__tag.html#a459df1597522bded6f203e36ed2cc722", null ],
    [ "m_pAlloc_opaque", "structmz__zip__archive__tag.html#abc59b536ad84bfc23fd8dd6fb80e5821", null ],
    [ "m_pFree", "structmz__zip__archive__tag.html#a99187a8cbda9084cc8aad170810d20bc", null ],
    [ "m_pIO_opaque", "structmz__zip__archive__tag.html#afe6dbd172dd42b80adb4b2dbc3a310fa", null ],
    [ "m_pRead", "structmz__zip__archive__tag.html#aaeb0dd8a865fd776e32b463b3183d3d7", null ],
    [ "m_pRealloc", "structmz__zip__archive__tag.html#a871937a81f88fed84d1632dfe4e22222", null ],
    [ "m_pState", "structmz__zip__archive__tag.html#aad50c7d0c1f23497a2d8648371c64ec8", null ],
    [ "m_pWrite", "structmz__zip__archive__tag.html#a55b7f9913bcd74aec667315e4598df0c", null ],
    [ "m_total_files", "structmz__zip__archive__tag.html#a34eb45b23728b47dda13d2a5d44e3268", null ],
    [ "m_zip_mode", "structmz__zip__archive__tag.html#a002006fe649d710372a47178f817d67f", null ]
];