var inffas86_8c =
[
    [ "PAD_AVAIL_IN", "inffas86_8c.html#a8f78a275a62b65dd5bdc54756b570384", null ],
    [ "PAD_AVAIL_OUT", "inffas86_8c.html#a83a35192ec882d2d874d6c1d78f7d51a", null ],
    [ "inflate_fast", "inffas86_8c.html#a53a180584225f8b9e863a9ab03c16076", null ]
];