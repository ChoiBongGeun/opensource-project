var inftree9_8h =
[
    [ "code", "structcode.html", "structcode" ],
    [ "ENOUGH", "inftree9_8h.html#acef2f42f16f168d23ec870bd60a3b5f1", null ],
    [ "ENOUGH_DISTS", "inftree9_8h.html#aa4f18dce1f4ecd74cfa8b18c8cd62933", null ],
    [ "ENOUGH_LENS", "inftree9_8h.html#a9785642d346454e272be30a8016dff04", null ],
    [ "codetype", "inftree9_8h.html#a0f33f5acf9079ff1f054fa235df2443b", [
      [ "CODES", "inftree9_8h.html#a0f33f5acf9079ff1f054fa235df2443ba4f2ec4135d8cf82c6c35780e470cac28", null ],
      [ "LENS", "inftree9_8h.html#a0f33f5acf9079ff1f054fa235df2443ba86b0f8050ddd8ae0b99e2f9323ad00a1", null ],
      [ "DISTS", "inftree9_8h.html#a0f33f5acf9079ff1f054fa235df2443bafd7fbb659c736b26e79316ef09a2a9a1", null ],
      [ "CODES", "inftrees_8h.html#a0f33f5acf9079ff1f054fa235df2443ba4f2ec4135d8cf82c6c35780e470cac28", null ],
      [ "LENS", "inftrees_8h.html#a0f33f5acf9079ff1f054fa235df2443ba86b0f8050ddd8ae0b99e2f9323ad00a1", null ],
      [ "DISTS", "inftrees_8h.html#a0f33f5acf9079ff1f054fa235df2443bafd7fbb659c736b26e79316ef09a2a9a1", null ]
    ] ],
    [ "OF", "inftree9_8h.html#a1785591ae10baac7de86f177c62efde7", null ]
];