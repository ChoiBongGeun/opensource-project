var pufftest_8c =
[
    [ "local", "pufftest_8c.html#a08023ea6765c99d60a6a3840cd07156e", null ],
    [ "SET_BINARY_MODE", "pufftest_8c.html#a714fe40d73494a577de3127a79ea24a2", null ],
    [ "bythirds", "pufftest_8c.html#a39e5864dd3210cc3001a3d5770dc1a2b", null ],
    [ "load", "pufftest_8c.html#a6e4d4615cece3375ac8c7b94a1ade4fa", null ],
    [ "main", "pufftest_8c.html#a3c04138a5bfe5d72780bb7e82a18e627", null ]
];