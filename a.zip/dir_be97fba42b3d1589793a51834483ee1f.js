var dir_be97fba42b3d1589793a51834483ee1f =
[
    [ "miniz.h", "miniz_8h.html", "miniz_8h" ],
    [ "zip.c", "zip_8c.html", "zip_8c" ],
    [ "zip.h", "zip_8h.html", "zip_8h" ]
];