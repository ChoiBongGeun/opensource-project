var classgzofstream =
[
    [ "gzofstream", "classgzofstream.html#ae92ce0e4696e29741ee979f08cf5f7d2", null ],
    [ "gzofstream", "classgzofstream.html#aad6a405bc9ecfd82cc0861a15e4a6983", null ],
    [ "gzofstream", "classgzofstream.html#a5291a0c4c0e7f6f18ca72ae98f4e4d40", null ],
    [ "~gzofstream", "classgzofstream.html#a0bb8fbe1347ddee2e349f0038bc4bee0", null ],
    [ "gzofstream", "classgzofstream.html#ae92ce0e4696e29741ee979f08cf5f7d2", null ],
    [ "gzofstream", "classgzofstream.html#a4334d31aab99f8c9c2277b672a55c78f", null ],
    [ "gzofstream", "classgzofstream.html#aa94d0c8414119a52f2a7f42aa0440941", null ],
    [ "attach", "classgzofstream.html#a95b76eaecd03b6cbf53d2f4b1c867439", null ],
    [ "close", "classgzofstream.html#a59e8b01e1c9741085f18ca456c4b8f54", null ],
    [ "is_open", "classgzofstream.html#acb1c9c6dccaf41bc5e44c2263ea48de3", null ],
    [ "open", "classgzofstream.html#aee3eb31f07eda7f5ad1f60d59ea4b239", null ],
    [ "rdbuf", "classgzofstream.html#a2fef74202b114357f41cfeb28f1d2acc", null ]
];