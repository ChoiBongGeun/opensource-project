var hierarchy =
[
    [ "access", "structaccess.html", null ],
    [ "ApplicationException", null, [
      [ "DotZLib.ZLibException", "class_dot_z_lib_1_1_z_lib_exception.html", null ]
    ] ],
    [ "attr_item", "structattr__item.html", null ],
    [ "bin", "structbin.html", null ],
    [ "DotZLib.ChecksumGenerator", "interface_dot_z_lib_1_1_checksum_generator.html", [
      [ "DotZLib.ChecksumGeneratorBase", "class_dot_z_lib_1_1_checksum_generator_base.html", [
        [ "DotZLib.AdlerChecksum", "class_dot_z_lib_1_1_adler_checksum.html", null ],
        [ "DotZLib.CRC32Checksum", "class_dot_z_lib_1_1_c_r_c32_checksum.html", null ]
      ] ]
    ] ],
    [ "code", "structcode.html", null ],
    [ "DotZLib.Codec", "interface_dot_z_lib_1_1_codec.html", [
      [ "DotZLib.CodecBase", "class_dot_z_lib_1_1_codec_base.html", [
        [ "DotZLib.Deflater", "class_dot_z_lib_1_1_deflater.html", null ],
        [ "DotZLib.Inflater", "class_dot_z_lib_1_1_inflater.html", null ]
      ] ]
    ] ],
    [ "config_s", "structconfig__s.html", null ],
    [ "ct_data_s", "structct__data__s.html", null ],
    [ "curfile64_info", "structcurfile64__info.html", null ],
    [ "file", "structfile.html", null ],
    [ "file_in_zip64_read_info_s", "structfile__in__zip64__read__info__s.html", null ],
    [ "gz_header_s", "structgz__header__s.html", null ],
    [ "gz_state", "structgz__state.html", null ],
    [ "gzFile_s", "structgz_file__s.html", null ],
    [ "gzomanip< T >", "classgzomanip.html", null ],
    [ "gzomanip2< T1, T2 >", "classgzomanip2.html", null ],
    [ "huffman", "structhuffman.html", null ],
    [ "IDisposable", null, [
      [ "DotZLib.CodecBase", "class_dot_z_lib_1_1_codec_base.html", null ],
      [ "DotZLib.GZipStream", "class_dot_z_lib_1_1_g_zip_stream.html", null ]
    ] ],
    [ "ind", "structind.html", null ],
    [ "inffast_ar", "structinffast__ar.html", null ],
    [ "inflate_state", "structinflate__state.html", null ],
    [ "DotZLib.Info", "class_dot_z_lib_1_1_info.html", null ],
    [ "internal_state", "structinternal__state.html", null ],
    [ "ios", null, [
      [ "gzfilestream_common", "classgzfilestream__common.html", [
        [ "gzifstream", "classgzifstream.html", null ],
        [ "gzofstream", "classgzofstream.html", null ]
      ] ]
    ] ],
    [ "istream", null, [
      [ "gzifstream", "classgzifstream.html", null ],
      [ "gzifstream", "classgzifstream.html", null ]
    ] ],
    [ "izstream", "classizstream.html", null ],
    [ "linkedlist_data_s", "structlinkedlist__data__s.html", null ],
    [ "linkedlist_datablock_internal_s", "structlinkedlist__datablock__internal__s.html", null ],
    [ "log", "structlog.html", null ],
    [ "mem_item", "structmem__item.html", null ],
    [ "mem_zone", "structmem__zone.html", null ],
    [ "ostream", null, [
      [ "gzofstream", "classgzofstream.html", null ],
      [ "gzofstream", "classgzofstream.html", null ]
    ] ],
    [ "outd", "structoutd.html", null ],
    [ "ozstream", "classozstream.html", null ],
    [ "point", "structpoint.html", null ],
    [ "state", "structstate.html", null ],
    [ "static_tree_desc_s", "structstatic__tree__desc__s.html", null ],
    [ "Stream", null, [
      [ "DotZLib.GZipStream", "class_dot_z_lib_1_1_g_zip_stream.html", null ]
    ] ],
    [ "streambuf", null, [
      [ "gzfilebuf", "classgzfilebuf.html", null ],
      [ "gzfilebuf", "classgzfilebuf.html", null ]
    ] ],
    [ "tab", "structtab.html", null ],
    [ "tar_buffer", "uniontar__buffer.html", null ],
    [ "tar_header", "structtar__header.html", null ],
    [ "tm_unz_s", "structtm__unz__s.html", null ],
    [ "tm_zip_s", "structtm__zip__s.html", null ],
    [ "tree_desc_s", "structtree__desc__s.html", null ],
    [ "unz64_file_pos_s", "structunz64__file__pos__s.html", null ],
    [ "unz64_s", "structunz64__s.html", null ],
    [ "unz_file_info64_internal_s", "structunz__file__info64__internal__s.html", null ],
    [ "unz_file_info64_s", "structunz__file__info64__s.html", null ],
    [ "unz_file_info_s", "structunz__file__info__s.html", null ],
    [ "unz_file_pos_s", "structunz__file__pos__s.html", null ],
    [ "unz_global_info64_s", "structunz__global__info64__s.html", null ],
    [ "unz_global_info_s", "structunz__global__info__s.html", null ],
    [ "WIN32FILE_IOWIN", "struct_w_i_n32_f_i_l_e___i_o_w_i_n.html", null ],
    [ "z_stream_s", "structz__stream__s.html", null ],
    [ "zip64_internal", "structzip64__internal.html", null ],
    [ "zip_fileinfo", "structzip__fileinfo.html", null ],
    [ "zlib_filefunc64_32_def_s", "structzlib__filefunc64__32__def__s.html", null ],
    [ "zlib_filefunc64_def_s", "structzlib__filefunc64__def__s.html", null ],
    [ "zlib_filefunc_def_s", "structzlib__filefunc__def__s.html", null ],
    [ "zstringlen", "classzstringlen.html", null ]
];