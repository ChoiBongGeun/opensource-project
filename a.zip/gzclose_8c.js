var gzclose_8c =
[
    [ "gzclose", "gzclose_8c.html#aa7cbb6800b5c2e3a897b4470fbb3abcd", null ]
];