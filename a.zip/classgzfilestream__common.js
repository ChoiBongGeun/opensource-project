var classgzfilestream__common =
[
    [ "~gzfilestream_common", "classgzfilestream__common.html#acc4fbd5566d5a1f42a443111322a2bb4", null ],
    [ "gzfilestream_common", "classgzfilestream__common.html#a7b074883506c1f5f45638d6f4dbdb9d4", null ],
    [ "attach", "classgzfilestream__common.html#a5d89983a0a4842ac15dddc7927031d7e", null ],
    [ "close", "classgzfilestream__common.html#a87aa2bfaf8876e1d63edafb7515aaf5f", null ],
    [ "open", "classgzfilestream__common.html#a642732c6ddbdc437ea996acecf7d419b", null ],
    [ "gzifstream", "classgzfilestream__common.html#a8868b8b017f99a3546def94f45c13b9a", null ],
    [ "gzofstream", "classgzfilestream__common.html#a6c603bc220f3120e5bbf9c04316ab930", null ],
    [ "setcompressionlevel", "classgzfilestream__common.html#a3351bd2cbcd5eedea805dfbf996f4236", null ],
    [ "setcompressionstrategy", "classgzfilestream__common.html#a37083e69bcbb72fd74685473a21eaa87", null ]
];