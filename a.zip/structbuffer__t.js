var structbuffer__t =
[
    [ "data", "structbuffer__t.html#a00b87d87c7190474819f665c8e304e70", null ],
    [ "size", "structbuffer__t.html#a43d8b16bd7c446a8b35c940ea44e23f7", null ]
];