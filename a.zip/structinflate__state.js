var structinflate__state =
[
    [ "m_decomp", "structinflate__state.html#aa112419e6fc485a0569d89b0dac4c40d", null ],
    [ "m_dict", "structinflate__state.html#a6d9569803f5139b8bb11b409f69f598b", null ],
    [ "m_dict_avail", "structinflate__state.html#a45eb73702d5588b380842d55633adfa1", null ],
    [ "m_dict_ofs", "structinflate__state.html#a26b59390ae38c5a0ee081a729479b89f", null ],
    [ "m_first_call", "structinflate__state.html#a8ed1d9e9a13f5e5f5c4229c67509a5a1", null ],
    [ "m_has_flushed", "structinflate__state.html#a26ee41a3a0d93350c737252334fe783f", null ],
    [ "m_last_status", "structinflate__state.html#a9d2e5eba1b8c7a5bf78289b7a412f154", null ],
    [ "m_window_bits", "structinflate__state.html#a05183fc4ee620dfaac7cdde5c17697a9", null ]
];