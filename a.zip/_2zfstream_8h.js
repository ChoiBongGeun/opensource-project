var _2zfstream_8h =
[
    [ "gzfilebuf", "classgzfilebuf.html", "classgzfilebuf" ],
    [ "gzifstream", "classgzifstream.html", "classgzifstream" ],
    [ "gzofstream", "classgzofstream.html", "classgzofstream" ],
    [ "gzomanip2", "classgzomanip2.html", "classgzomanip2" ],
    [ "operator<<", "_2zfstream_8h.html#a62a73c5962cb539b3194b9cd8e81cb01", null ],
    [ "setcompression", "_2zfstream_8h.html#aab289b98ea9cf29d109df4969c77bc10", null ],
    [ "setcompression", "_2zfstream_8h.html#a9faf10ab9ba2398c393ad3691421c180", null ]
];