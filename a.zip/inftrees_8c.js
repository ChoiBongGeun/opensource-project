var inftrees_8c =
[
    [ "MAXBITS", "inftrees_8c.html#a6fcad31e688110d9d61bdcc99b2a59d7", null ],
    [ "inflate_table", "inftrees_8c.html#a773e6164ab27c6f3ea71144dfc487c7f", null ],
    [ "inflate_copyright", "inftrees_8c.html#a01f427c9f5e8158ec52760a1c896e8be", null ]
];