var annotated_dup =
[
    [ "buffer_t", "structbuffer__t.html", "structbuffer__t" ],
    [ "inflate_state", "structinflate__state.html", "structinflate__state" ],
    [ "mz_stream_s", "structmz__stream__s.html", "structmz__stream__s" ],
    [ "mz_zip_archive_file_stat", "structmz__zip__archive__file__stat.html", "structmz__zip__archive__file__stat" ],
    [ "mz_zip_archive_tag", "structmz__zip__archive__tag.html", "structmz__zip__archive__tag" ],
    [ "mz_zip_array", "structmz__zip__array.html", "structmz__zip__array" ],
    [ "mz_zip_internal_state_tag", "structmz__zip__internal__state__tag.html", "structmz__zip__internal__state__tag" ],
    [ "mz_zip_writer_add_state", "structmz__zip__writer__add__state.html", "structmz__zip__writer__add__state" ],
    [ "tdefl_compressor", "structtdefl__compressor.html", "structtdefl__compressor" ],
    [ "tdefl_output_buffer", "structtdefl__output__buffer.html", "structtdefl__output__buffer" ],
    [ "tdefl_sym_freq", "structtdefl__sym__freq.html", "structtdefl__sym__freq" ],
    [ "tinfl_decompressor_tag", "structtinfl__decompressor__tag.html", "structtinfl__decompressor__tag" ],
    [ "tinfl_huff_table", "structtinfl__huff__table.html", "structtinfl__huff__table" ],
    [ "zip_entry_t", "structzip__entry__t.html", "structzip__entry__t" ],
    [ "zip_t", "structzip__t.html", "structzip__t" ]
];