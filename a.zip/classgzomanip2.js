var classgzomanip2 =
[
    [ "gzomanip2", "classgzomanip2.html#a6e3980ce2fa39e29ecfa537bb8e9ddb0", null ],
    [ "operator<<", "classgzomanip2.html#a2382d2b86b2af773d17c2bc349fddb4f", null ]
];