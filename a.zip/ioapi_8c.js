var ioapi_8c =
[
    [ "FOPEN_FUNC", "ioapi_8c.html#a522a01bfc7c0429ab53987e50458fe8c", null ],
    [ "FSEEKO_FUNC", "ioapi_8c.html#a0e74e519db7ea2da026a7da7eac65c7c", null ],
    [ "FTELLO_FUNC", "ioapi_8c.html#ae84e3319767599bbef3ccbdeb4b0a3e4", null ],
    [ "call_zopen64", "ioapi_8c.html#aba1d7f2b69248eee96210089ce140925", null ],
    [ "call_zseek64", "ioapi_8c.html#aa3566299e354e3275a72193ab48e4af3", null ],
    [ "call_ztell64", "ioapi_8c.html#ad18411c799d4ef86d37e25610e411c93", null ],
    [ "fill_fopen64_filefunc", "ioapi_8c.html#aa67e4de04de04bf2d1694febd74bd16f", null ],
    [ "fill_fopen_filefunc", "ioapi_8c.html#ab44f1d585b26ce7f9447a91ada432727", null ],
    [ "fill_zlib_filefunc64_32_def_from_filefunc32", "ioapi_8c.html#a0c90747a8b732158bc3666411776affe", null ]
];