var minigzip_8c =
[
    [ "BUFLEN", "minigzip_8c.html#ad974fe981249f5e84fbf1683b012c9f8", null ],
    [ "GZ_SUFFIX", "minigzip_8c.html#af0358042fe986b270acfb8e365b2811e", null ],
    [ "local", "minigzip_8c.html#a08023ea6765c99d60a6a3840cd07156e", null ],
    [ "MAX_NAME_LEN", "minigzip_8c.html#afd709f201d7643c3909621f620ea648a", null ],
    [ "SET_BINARY_MODE", "minigzip_8c.html#a714fe40d73494a577de3127a79ea24a2", null ],
    [ "SUFFIX_LEN", "minigzip_8c.html#a5a10308ce506a5645ae1e8b5e18dfded", null ],
    [ "error", "minigzip_8c.html#aee763da2c1c9da197307bad1d009513d", null ],
    [ "file_compress", "minigzip_8c.html#adc77afce5b88d03ff5b7f3e601ffbeda", null ],
    [ "file_uncompress", "minigzip_8c.html#a8321abed5f7b240ea8b3479cb20ea999", null ],
    [ "gz_compress", "minigzip_8c.html#a0bf16f4e4ac30fb8e3f5a1cd65a19b3a", null ],
    [ "gz_uncompress", "minigzip_8c.html#a008fe95a4c4c4df12575bc671d060c02", null ],
    [ "main", "minigzip_8c.html#afced8478b91af5c169926dfa4426333d", null ],
    [ "OF", "minigzip_8c.html#a3a8ee759d3069590b48d34e4580afcdd", null ],
    [ "OF", "minigzip_8c.html#ae1d0289f7e007ba80f0b06636032f1a0", null ],
    [ "OF", "minigzip_8c.html#a1bd105659c9a94b22a297cbed765279d", null ],
    [ "OF", "minigzip_8c.html#aeae4c8cbb80354681524c0ad7ebc43a4", null ],
    [ "OF", "minigzip_8c.html#a206be0aff114ca0ba609fab68623bddc", null ],
    [ "OF", "minigzip_8c.html#a562b6fa2a839d04437d3defe387bb276", null ],
    [ "OF", "minigzip_8c.html#af1ff1f3dedc732d54aa58e3399fe7652", null ]
];