var dir_09e31043d1a70bf6d24fa5b20eed7597 =
[
    [ "puff.c", "puff_8c.html", "puff_8c" ],
    [ "puff.h", "puff_8h.html", "puff_8h" ],
    [ "pufftest.c", "pufftest_8c.html", "pufftest_8c" ]
];