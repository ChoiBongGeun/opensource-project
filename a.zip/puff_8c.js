var puff_8c =
[
    [ "state", "structstate.html", "structstate" ],
    [ "huffman", "structhuffman.html", "structhuffman" ],
    [ "FIXLCODES", "puff_8c.html#a07f2d271bc15402e50a75a2b580ccb38", null ],
    [ "local", "puff_8c.html#a08023ea6765c99d60a6a3840cd07156e", null ],
    [ "MAXBITS", "puff_8c.html#a6fcad31e688110d9d61bdcc99b2a59d7", null ],
    [ "MAXCODES", "puff_8c.html#a4b99f94b98defb9b267ea98c2b7ed35b", null ],
    [ "MAXDCODES", "puff_8c.html#a1caf3c3995675a37b8db90112ac276bb", null ],
    [ "MAXLCODES", "puff_8c.html#a882cea3ad6d6a7b1af23998cca38fff8", null ],
    [ "bits", "puff_8c.html#af23433d9d58fb31d4a1ac224e3bc46e8", null ],
    [ "codes", "puff_8c.html#a9251a2dbe9d416cf6485572defe42220", null ],
    [ "construct", "puff_8c.html#a9992feabb3d1b3381503dfb89222251f", null ],
    [ "decode", "puff_8c.html#a226cd632d2d1d565d2e7c6e16f9dc837", null ],
    [ "dynamic", "puff_8c.html#a5f81f35c5fef404a03c7059b39ab45f1", null ],
    [ "fixed", "puff_8c.html#af3340594bb80768552b17efb18581c98", null ],
    [ "puff", "puff_8c.html#a37210080eeb63cf5200b5fd61ca89d06", null ],
    [ "stored", "puff_8c.html#a2c157e80e65abde8e3f64853a41bfecc", null ]
];