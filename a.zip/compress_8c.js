var compress_8c =
[
    [ "ZLIB_INTERNAL", "compress_8c.html#a59d4d7ef4d73655c759211ec33a5d44f", null ],
    [ "compress", "compress_8c.html#aef315743418d760a360e1be293d27cd1", null ],
    [ "compress2", "compress_8c.html#aede7e438c033a969a1a40ba6b44f91f9", null ],
    [ "compressBound", "compress_8c.html#a6bfd92b4426ff6008c841c2cc6f8fed3", null ]
];