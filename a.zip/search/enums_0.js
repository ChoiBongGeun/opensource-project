var searchData=
[
  ['mz_5fzip_5fflags',['mz_zip_flags',['../miniz_8h.html#a0b7f6f797da7a3d078535ba71ca00858',1,'miniz.h']]],
  ['mz_5fzip_5fmode',['mz_zip_mode',['../miniz_8h.html#ad909f6ff4c74a79b317e306a164c77f3',1,'miniz.h']]]
];
