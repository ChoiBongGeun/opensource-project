var searchData=
[
  ['header',['header',['../structzip__entry__t.html#aee5b6c5e6c344349895ea2588f32e75a',1,'zip_entry_t']]],
  ['header_5foffset',['header_offset',['../structzip__entry__t.html#aaddf5f588ad62f3a8cb61c06fd7596c4',1,'zip_entry_t']]]
];
