var searchData=
[
  ['tdefl_5fcompress',['tdefl_compress',['../miniz_8h.html#ae9968978f7ea9f732c5ed08db988208b',1,'miniz.h']]],
  ['tdefl_5fcompress_5fbuffer',['tdefl_compress_buffer',['../miniz_8h.html#a5f2608070112b0e81a3017e9c39c73b7',1,'miniz.h']]],
  ['tdefl_5fcompress_5fmem_5fto_5fheap',['tdefl_compress_mem_to_heap',['../miniz_8h.html#a20ae6e4fc0382a7dc08d7029891bbe37',1,'miniz.h']]],
  ['tdefl_5fcompress_5fmem_5fto_5fmem',['tdefl_compress_mem_to_mem',['../miniz_8h.html#a37639f95844a8c30995fc1f5d4bb75a1',1,'miniz.h']]],
  ['tdefl_5fcompress_5fmem_5fto_5foutput',['tdefl_compress_mem_to_output',['../miniz_8h.html#a153fd833b8c09efd13aa1d35dd22d092',1,'miniz.h']]],
  ['tdefl_5fcreate_5fcomp_5fflags_5ffrom_5fzip_5fparams',['tdefl_create_comp_flags_from_zip_params',['../miniz_8h.html#acf2306ec6b7f92753264f68bc554750b',1,'miniz.h']]],
  ['tdefl_5fget_5fadler32',['tdefl_get_adler32',['../miniz_8h.html#a2ec6403111ea9afbcdc4d76cfda97110',1,'miniz.h']]],
  ['tdefl_5fget_5fprev_5freturn_5fstatus',['tdefl_get_prev_return_status',['../miniz_8h.html#a516a79788364e4f3e3b55187a2a67b24',1,'miniz.h']]],
  ['tdefl_5finit',['tdefl_init',['../miniz_8h.html#a3c2c67a6200147020ba4bfbf77962792',1,'miniz.h']]],
  ['tdefl_5fwrite_5fimage_5fto_5fpng_5ffile_5fin_5fmemory',['tdefl_write_image_to_png_file_in_memory',['../miniz_8h.html#acbd51872040a606caa8bf290a85e8be3',1,'miniz.h']]],
  ['tdefl_5fwrite_5fimage_5fto_5fpng_5ffile_5fin_5fmemory_5fex',['tdefl_write_image_to_png_file_in_memory_ex',['../miniz_8h.html#a1ed893f615dda47d07210d50b825578f',1,'miniz.h']]],
  ['tinfl_5fdecompress',['tinfl_decompress',['../miniz_8h.html#ac4e4c006d234780922676ecc31fe1416',1,'miniz.h']]],
  ['tinfl_5fdecompress_5fmem_5fto_5fcallback',['tinfl_decompress_mem_to_callback',['../miniz_8h.html#a3e8087762c8423c4e48d1e5e01a243de',1,'miniz.h']]],
  ['tinfl_5fdecompress_5fmem_5fto_5fheap',['tinfl_decompress_mem_to_heap',['../miniz_8h.html#a4132a2c848f7a8b3db82735f0abb80f9',1,'miniz.h']]],
  ['tinfl_5fdecompress_5fmem_5fto_5fmem',['tinfl_decompress_mem_to_mem',['../miniz_8h.html#ac4642bb91b5abc566c6b23c0658d6995',1,'miniz.h']]]
];
