var indexSectionsWithContent =
{
  0: "_abcdefhilmnorstuvwxz",
  1: "bimtz",
  2: "mrtz",
  3: "mstz",
  4: "acdehilmnorstuz",
  5: "bcimstuv",
  6: "mt",
  7: "mt",
  8: "_acdfhimrstuwxz",
  9: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "모두",
  1: "클래스",
  2: "파일들",
  3: "함수",
  4: "변수",
  5: "타입정의",
  6: "열거형 타입",
  7: "열거형 멤버",
  8: "매크로",
  9: "페이지들"
};

