var searchData=
[
  ['intf',['intf',['../miniz_8h.html#a7c2da1a4711ea1e7cbf3174d4f5dda9b',1,'miniz.h']]]
];
