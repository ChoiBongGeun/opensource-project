var searchData=
[
  ['byte',['Byte',['../miniz_8h.html#ae3a497195d617519e5353ea7b417940f',1,'miniz.h']]],
  ['bytef',['Bytef',['../miniz_8h.html#ac5613fe8160cbbf89d3e470574b755fb',1,'miniz.h']]]
];
