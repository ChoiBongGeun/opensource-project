var searchData=
[
  ['linkedlist_5fdata_5fs',['linkedlist_data_s',['../structlinkedlist__data__s.html',1,'']]],
  ['linkedlist_5fdatablock_5finternal_5fs',['linkedlist_datablock_internal_s',['../structlinkedlist__datablock__internal__s.html',1,'']]],
  ['log',['log',['../structlog.html',1,'']]]
];
