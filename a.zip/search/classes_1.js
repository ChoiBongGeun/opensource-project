var searchData=
[
  ['bin',['bin',['../structbin.html',1,'']]]
];
