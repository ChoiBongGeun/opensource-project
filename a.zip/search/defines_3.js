var searchData=
[
  ['deflate',['deflate',['../miniz_8h.html#a04be214323e3ae74865fa6f7006a16fd',1,'miniz.h']]],
  ['deflatebound',['deflateBound',['../miniz_8h.html#a56f41bdffa865e02ed160ebdc54b5d87',1,'miniz.h']]],
  ['deflateend',['deflateEnd',['../miniz_8h.html#a0a4adb4287e6b8f1f239821ee15834b5',1,'miniz.h']]],
  ['deflateinit',['deflateInit',['../miniz_8h.html#a5e9d5f0b1abf4368ac4d55b0909dcd99',1,'miniz.h']]],
  ['deflateinit2',['deflateInit2',['../miniz_8h.html#a5fdefdacf3bc7c8484df6e8b7bd5b2bc',1,'miniz.h']]],
  ['deflatereset',['deflateReset',['../miniz_8h.html#acd6a182af06163cb069f9e3a61dbac73',1,'miniz.h']]]
];
