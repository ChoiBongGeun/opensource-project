var searchData=
[
  ['tdefl_5fput_5fbuf_5ffunc_5fptr',['tdefl_put_buf_func_ptr',['../miniz_8h.html#ad9ea9d3eac48ba0658f750a920452497',1,'miniz.h']]],
  ['tinfl_5fbit_5fbuf_5ft',['tinfl_bit_buf_t',['../miniz_8h.html#af6af194c507342cda458498cd37ca418',1,'miniz.h']]],
  ['tinfl_5fdecompressor',['tinfl_decompressor',['../miniz_8h.html#ad5308cf24962df49c8b6a5c91bbbe05e',1,'miniz.h']]],
  ['tinfl_5fput_5fbuf_5ffunc_5fptr',['tinfl_put_buf_func_ptr',['../miniz_8h.html#a4e4ea4a3376e8d2a996b848c8e4319df',1,'miniz.h']]]
];
