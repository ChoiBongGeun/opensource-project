var searchData=
[
  ['name',['name',['../structzip__entry__t.html#a6e2873a477844002286fed23f74d1e82',1,'zip_entry_t']]],
  ['next_5fin',['next_in',['../structmz__stream__s.html#aa75ed42cc83b0f74d7fcce6299439307',1,'mz_stream_s']]],
  ['next_5fout',['next_out',['../structmz__stream__s.html#a2c569383efce3b9d9e7c02e3e03941bc',1,'mz_stream_s']]]
];
