var searchData=
[
  ['size',['size',['../structbuffer__t.html#a43d8b16bd7c446a8b35c940ea44e23f7',1,'buffer_t']]],
  ['ssize_5ft',['ssize_t',['../zip_8h.html#a831c6b6852c6d34448e30a88c34539fd',1,'zip.h']]],
  ['state',['state',['../structmz__stream__s.html#a935cdb239d37161b5a5e6eda1e047df6',1,'mz_stream_s::state()'],['../structzip__entry__t.html#a324592620d55a44fe6b7178cf5062d05',1,'zip_entry_t::state()']]],
  ['strclone',['STRCLONE',['../zip_8c.html#a88046310133687164e110ddf6e21fc5a',1,'zip.c']]],
  ['symlink',['symlink',['../zip_8c.html#a85923fecf6e7f8cd74ed04597cd40f74',1,'zip.c']]]
];
