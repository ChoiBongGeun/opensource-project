var searchData=
[
  ['huffman',['huffman',['../structhuffman.html',1,'']]]
];
