var searchData=
[
  ['entry',['entry',['../structzip__t.html#aee479cc5e2106c5953c9c65851910ab9',1,'zip_t']]],
  ['external_5fattr',['external_attr',['../structzip__entry__t.html#a9a3ac29f98a4722d7612f8b6e40485e5',1,'zip_entry_t']]]
];
