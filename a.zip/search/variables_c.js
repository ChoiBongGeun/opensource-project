var searchData=
[
  ['total_5fin',['total_in',['../structmz__stream__s.html#abfa083eb7707360c33389ec12fadf376',1,'mz_stream_s']]],
  ['total_5fout',['total_out',['../structmz__stream__s.html#a5cf2c15cc49a99ee7d541375798a3e27',1,'mz_stream_s']]]
];
