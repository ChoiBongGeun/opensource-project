var searchData=
[
  ['win32file_5fiowin',['WIN32FILE_IOWIN',['../struct_w_i_n32_f_i_l_e___i_o_w_i_n.html',1,'']]]
];
