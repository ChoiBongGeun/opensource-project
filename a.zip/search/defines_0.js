var searchData=
[
  ['_5f_5fuse_5ffile_5foffset64',['__USE_FILE_OFFSET64',['../ioapi_8h.html#aa873b7168492eebce909df8415cac735',1,'__USE_FILE_OFFSET64():&#160;ioapi.h'],['../miniunz_8c.html#aa873b7168492eebce909df8415cac735',1,'__USE_FILE_OFFSET64():&#160;miniunz.c'],['../minizip_8c.html#aa873b7168492eebce909df8415cac735',1,'__USE_FILE_OFFSET64():&#160;minizip.c']]],
  ['_5f_5fuse_5flargefile64',['__USE_LARGEFILE64',['../ioapi_8h.html#a285ae8236e7a984a6692acf6530cd505',1,'__USE_LARGEFILE64():&#160;ioapi.h'],['../miniunz_8c.html#a285ae8236e7a984a6692acf6530cd505',1,'__USE_LARGEFILE64():&#160;miniunz.c'],['../minizip_8c.html#a285ae8236e7a984a6692acf6530cd505',1,'__USE_LARGEFILE64():&#160;minizip.c']]],
  ['_5ffile_5foffset_5fbit',['_FILE_OFFSET_BIT',['../ioapi_8h.html#ac86701761e1b32d5d7a3358a6c726efa',1,'_FILE_OFFSET_BIT():&#160;ioapi.h'],['../miniunz_8c.html#ac86701761e1b32d5d7a3358a6c726efa',1,'_FILE_OFFSET_BIT():&#160;miniunz.c'],['../minizip_8c.html#ac86701761e1b32d5d7a3358a6c726efa',1,'_FILE_OFFSET_BIT():&#160;minizip.c']]],
  ['_5flargefile64_5fsource',['_LARGEFILE64_SOURCE',['../ioapi_8h.html#a0e6d20c5075b52b0f0bc4858d51c8591',1,'_LARGEFILE64_SOURCE():&#160;ioapi.h'],['../miniunz_8c.html#a0e6d20c5075b52b0f0bc4858d51c8591',1,'_LARGEFILE64_SOURCE():&#160;miniunz.c'],['../minizip_8c.html#a0e6d20c5075b52b0f0bc4858d51c8591',1,'_LARGEFILE64_SOURCE():&#160;minizip.c']]],
  ['_5fposix_5fsource',['_POSIX_SOURCE',['../gzguts_8h.html#ac3d144aa01e765a1fae62ab5491c7cc1',1,'gzguts.h']]],
  ['_5ftr_5ftally_5fdist',['_tr_tally_dist',['../deflate_8h.html#a68f55cdd396ad603d9f0b01afdbdf592',1,'deflate.h']]],
  ['_5ftr_5ftally_5flit',['_tr_tally_lit',['../deflate_8h.html#af3b11322da0fb4ec60a5ccc28e2554df',1,'deflate.h']]]
];
