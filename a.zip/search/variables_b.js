var searchData=
[
  ['size',['size',['../structbuffer__t.html#a43d8b16bd7c446a8b35c940ea44e23f7',1,'buffer_t']]],
  ['state',['state',['../structmz__stream__s.html#a935cdb239d37161b5a5e6eda1e047df6',1,'mz_stream_s::state()'],['../structzip__entry__t.html#a324592620d55a44fe6b7178cf5062d05',1,'zip_entry_t::state()']]]
];
