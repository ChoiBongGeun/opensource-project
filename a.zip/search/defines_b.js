var searchData=
[
  ['uncompress',['uncompress',['../miniz_8h.html#a0a7eedf0dba136b3a92685a8f625b8e7',1,'miniz.h']]],
  ['unused',['UNUSED',['../test_8c.html#a86d500a34c624c2cae56bc25a31b12f3',1,'test.c']]]
];
