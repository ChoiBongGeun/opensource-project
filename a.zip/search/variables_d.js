var searchData=
[
  ['uncomp_5fcrc32',['uncomp_crc32',['../structzip__entry__t.html#a9198d6cc15b29592d9135dfe15fb08df',1,'zip_entry_t']]],
  ['uncomp_5fsize',['uncomp_size',['../structzip__entry__t.html#aed12cc7f61192b0b0f73ddfe49442b23',1,'zip_entry_t']]]
];
