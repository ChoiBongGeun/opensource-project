var searchData=
[
  ['_5f_5fstdc_5fwant_5flib_5fext1_5f_5f',['__STDC_WANT_LIB_EXT1__',['../zip_8c.html#a7a104b2e349617222c6419b36bfd3260',1,'zip.c']]],
  ['_5fssize_5ft',['_SSIZE_T',['../zip_8h.html#a4460ee1eb123f97ece06e7e238094fd0',1,'zip.h']]]
];
