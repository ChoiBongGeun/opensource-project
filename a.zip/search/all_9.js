var searchData=
[
  ['level',['level',['../structzip__t.html#a95f8b4b0c8d33d3e198dccc8f3f17114',1,'zip_t']]]
];
