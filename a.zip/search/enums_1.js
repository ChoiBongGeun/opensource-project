var searchData=
[
  ['tdefl_5fflush',['tdefl_flush',['../miniz_8h.html#a9bfa87b1c54146014408fcca1bf37abf',1,'miniz.h']]],
  ['tdefl_5fstatus',['tdefl_status',['../miniz_8h.html#abe27406ab0ea1c4d615d93a3e688748f',1,'miniz.h']]],
  ['tinfl_5fstatus',['tinfl_status',['../miniz_8h.html#a387ccd3d7a7891c9e1d6ec4f4207c8d4',1,'miniz.h']]]
];
