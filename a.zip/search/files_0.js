var searchData=
[
  ['miniz_2eh',['miniz.h',['../miniz_8h.html',1,'']]]
];
