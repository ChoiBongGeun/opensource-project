var searchData=
[
  ['charf',['charf',['../miniz_8h.html#a864fa0e2e4e499038305f3276990689b',1,'miniz.h']]]
];
