var searchData=
[
  ['zalloc',['zalloc',['../structmz__stream__s.html#abbd8109a7f88713f39b9e3046a223ef2',1,'mz_stream_s']]],
  ['zfree',['zfree',['../structmz__stream__s.html#a55dbac0e9b86472bfa41f86dfb35df9a',1,'mz_stream_s']]]
];
