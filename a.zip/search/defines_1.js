var searchData=
[
  ['adler32',['adler32',['../miniz_8h.html#a88899508e9a73aad5db1854cd1cc87d7',1,'miniz.h']]],
  ['alloc_5ffunc',['alloc_func',['../miniz_8h.html#a4719a257e0920f8212b267186ea81083',1,'miniz.h']]]
];
