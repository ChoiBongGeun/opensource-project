var searchData=
[
  ['tdefl_5fcompressor',['tdefl_compressor',['../structtdefl__compressor.html',1,'']]],
  ['tdefl_5foutput_5fbuffer',['tdefl_output_buffer',['../structtdefl__output__buffer.html',1,'']]],
  ['tdefl_5fsym_5ffreq',['tdefl_sym_freq',['../structtdefl__sym__freq.html',1,'']]],
  ['tinfl_5fdecompressor_5ftag',['tinfl_decompressor_tag',['../structtinfl__decompressor__tag.html',1,'']]],
  ['tinfl_5fhuff_5ftable',['tinfl_huff_table',['../structtinfl__huff__table.html',1,'']]]
];
