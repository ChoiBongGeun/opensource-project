var searchData=
[
  ['xfile',['XFILE',['../test_8c.html#ac24922843682a0947847063be3180b12',1,'test.c']]],
  ['xmode',['XMODE',['../test_8c.html#a40a507a9d967e3131aea8424ad7b097f',1,'test.c']]]
];
