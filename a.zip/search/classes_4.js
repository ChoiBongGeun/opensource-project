var searchData=
[
  ['file',['file',['../structfile.html',1,'']]],
  ['file_5fin_5fzip64_5fread_5finfo_5fs',['file_in_zip64_read_info_s',['../structfile__in__zip64__read__info__s.html',1,'']]]
];
