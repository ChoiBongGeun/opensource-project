var searchData=
[
  ['data',['data',['../structbuffer__t.html#a00b87d87c7190474819f665c8e304e70',1,'buffer_t']]],
  ['data_5ftype',['data_type',['../structmz__stream__s.html#a3e1503f72464a3b7b40d1df232ba9f43',1,'mz_stream_s']]]
];
