var searchData=
[
  ['kbuffersize',['kBufferSize',['../class_dot_z_lib_1_1_codec_base.html#a6cf60968f7eaa921e5a8108e0ebcb880',1,'DotZLib::CodecBase']]],
  ['keys',['keys',['../structcurfile64__info.html#a1c4fff54045c80444eb155d42f6e58de',1,'curfile64_info']]]
];
