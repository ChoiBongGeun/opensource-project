var searchData=
[
  ['reserved',['reserved',['../structmz__stream__s.html#ae4fc708fffee7b10a4586964401613fb',1,'mz_stream_s']]]
];
