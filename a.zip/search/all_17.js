var searchData=
[
  ['x',['x',['../structgz__state.html#a92b9a7b77e0b6a494275d8bf0f0f3274',1,'gz_state']]],
  ['xflags',['xflags',['../structgz__header__s.html#a40e35dc1a967c6537c6012cf5416210a',1,'gz_header_s']]]
];
