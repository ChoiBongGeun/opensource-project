var searchData=
[
  ['offset',['offset',['../structzip__entry__t.html#aa41c0267e22c55b948c696cc8d789b6c',1,'zip_entry_t']]],
  ['opaque',['opaque',['../structmz__stream__s.html#a31c21928246598992a5cce6d20ae7e78',1,'mz_stream_s']]]
];
