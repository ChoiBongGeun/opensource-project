var searchData=
[
  ['rfile',['RFILE',['../test_8c.html#af69318ea4c03a0128fb3a04cfec4e4ca',1,'test.c']]],
  ['rmode',['RMODE',['../test_8c.html#a779d0d1c39fa4f9ef5104a43f909b820',1,'test.c']]]
];
