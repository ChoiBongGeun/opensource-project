var searchData=
[
  ['readme_2emd',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['reserved',['reserved',['../structmz__stream__s.html#ae4fc708fffee7b10a4586964401613fb',1,'mz_stream_s']]],
  ['rfile',['RFILE',['../test_8c.html#af69318ea4c03a0128fb3a04cfec4e4ca',1,'test.c']]],
  ['rmode',['RMODE',['../test_8c.html#a779d0d1c39fa4f9ef5104a43f909b820',1,'test.c']]]
];
