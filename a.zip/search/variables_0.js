var searchData=
[
  ['adler',['adler',['../structmz__stream__s.html#a24c6cf42b5b6a655f4664dd15203dce7',1,'mz_stream_s']]],
  ['archive',['archive',['../structzip__t.html#ac491c25b4d8afa85e4a41272d0089add',1,'zip_t']]],
  ['avail_5fin',['avail_in',['../structmz__stream__s.html#aafcd4c220622ede6d54015f1fbdadd9e',1,'mz_stream_s']]],
  ['avail_5fout',['avail_out',['../structmz__stream__s.html#a9092fed61f7be520fb1bbcf152905ee8',1,'mz_stream_s']]]
];
