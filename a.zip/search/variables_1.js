var searchData=
[
  ['comp',['comp',['../structzip__entry__t.html#a79675cd05faed3a9ea895d5808399dc0',1,'zip_entry_t']]],
  ['comp_5fsize',['comp_size',['../structzip__entry__t.html#a28e5cc79882ca7b963d7bd39aa393266',1,'zip_entry_t']]]
];
