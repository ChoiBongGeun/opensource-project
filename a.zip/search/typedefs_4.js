var searchData=
[
  ['ssize_5ft',['ssize_t',['../zip_8h.html#a831c6b6852c6d34448e30a88c34539fd',1,'zip.h']]]
];
