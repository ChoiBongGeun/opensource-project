var gun_8c =
[
    [ "ind", "structind.html", "structind" ],
    [ "outd", "structoutd.html", "structoutd" ],
    [ "FLUSHCODE", "gun_8c.html#a2476600d18a986007308d733126b1280", null ],
    [ "local", "gun_8c.html#a08023ea6765c99d60a6a3840cd07156e", null ],
    [ "NEXT", "gun_8c.html#afa19e2eadb751f3599e443d073862a2f", null ],
    [ "PIECE", "gun_8c.html#aed8b6e0ed4063c3f37022a1f676c36e7", null ],
    [ "SIZE", "gun_8c.html#a70ed59adcb4159ac551058053e649640", null ],
    [ "copymeta", "gun_8c.html#a4045bf219ee9c7ead9b2d49d1b82260a", null ],
    [ "gunpipe", "gun_8c.html#a70712ac76f1fd857664d8cab1332cb0c", null ],
    [ "gunzip", "gun_8c.html#aaa7062e7d81d5bada0aa1980b05e066f", null ],
    [ "in", "gun_8c.html#a8bab68b4d22f69428207fabb60dc4f5c", null ],
    [ "lunpipe", "gun_8c.html#aa3f761af43deaa5e14757df4b7da2344", null ],
    [ "main", "gun_8c.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "out", "gun_8c.html#acb2d4658684492100bc328998f52ae82", null ],
    [ "inbuf", "gun_8c.html#ae272c939af066c306dd6c491efc32add", null ],
    [ "match", "gun_8c.html#a3ec837ef2cea696af366fcfb455094c6", null ],
    [ "outbuf", "gun_8c.html#a39930321a199330d37e05ca07fb7b093", null ],
    [ "prefix", "gun_8c.html#ada2f6550a9ffe8e311af824df31c6064", null ],
    [ "suffix", "gun_8c.html#a143c3ff770154542cc6bd4602c3148a9", null ]
];