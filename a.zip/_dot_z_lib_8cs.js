var _dot_z_lib_8cs =
[
    [ "ZLibException", "class_dot_z_lib_1_1_z_lib_exception.html", "class_dot_z_lib_1_1_z_lib_exception" ],
    [ "ChecksumGenerator", "interface_dot_z_lib_1_1_checksum_generator.html", "interface_dot_z_lib_1_1_checksum_generator" ],
    [ "Codec", "interface_dot_z_lib_1_1_codec.html", "interface_dot_z_lib_1_1_codec" ],
    [ "Info", "class_dot_z_lib_1_1_info.html", "class_dot_z_lib_1_1_info" ],
    [ "CompressLevel", "_dot_z_lib_8cs.html#a034f7a1ef9856d8834e6f6b1c53d8a4c", [
      [ "Default", "_dot_z_lib_8cs.html#a034f7a1ef9856d8834e6f6b1c53d8a4ca7a1920d61156abc05a60135aefe8bc67", null ],
      [ "None", "_dot_z_lib_8cs.html#a034f7a1ef9856d8834e6f6b1c53d8a4ca6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "Best", "_dot_z_lib_8cs.html#a034f7a1ef9856d8834e6f6b1c53d8a4ca68ef004de6166492c1d668eb8efe09bd", null ],
      [ "Fastest", "_dot_z_lib_8cs.html#a034f7a1ef9856d8834e6f6b1c53d8a4ca90fd7fdf6f41406a75e5265b9583bb4e", null ]
    ] ],
    [ "FlushTypes", "_dot_z_lib_8cs.html#adac13a8cda185d449b34d1be7b97bdc2", [
      [ "None", "_dot_z_lib_8cs.html#adac13a8cda185d449b34d1be7b97bdc2a6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "Partial", "_dot_z_lib_8cs.html#adac13a8cda185d449b34d1be7b97bdc2a44ffd38a6dea695cbe2b34efdcc6cf27", null ],
      [ "Sync", "_dot_z_lib_8cs.html#adac13a8cda185d449b34d1be7b97bdc2ad8e87c0927539672f54462c837be0b7f", null ],
      [ "Full", "_dot_z_lib_8cs.html#adac13a8cda185d449b34d1be7b97bdc2abbd47109890259c0127154db1af26c75", null ],
      [ "Finish", "_dot_z_lib_8cs.html#adac13a8cda185d449b34d1be7b97bdc2aa20ddccbb6f808ec42cd66323e6c6061", null ],
      [ "Block", "_dot_z_lib_8cs.html#adac13a8cda185d449b34d1be7b97bdc2ae1e4c8c9ccd9fc39c391da4bcd093fb2", null ]
    ] ],
    [ "DataAvailableHandler", "_dot_z_lib_8cs.html#a3aa323950a96dc02f6b94462d498bfef", null ]
];