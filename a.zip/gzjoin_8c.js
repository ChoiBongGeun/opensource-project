var gzjoin_8c =
[
    [ "bin", "structbin.html", "structbin" ],
    [ "bget", "gzjoin_8c.html#a08080d1046f9396b99899a15eefba90b", null ],
    [ "CHUNK", "gzjoin_8c.html#a25022864dfc8ec428e7128282e57b136", null ],
    [ "local", "gzjoin_8c.html#a08023ea6765c99d60a6a3840cd07156e", null ],
    [ "bail", "gzjoin_8c.html#a9ee872f7ac6da578c4371ab6ad9e46d6", null ],
    [ "bclose", "gzjoin_8c.html#aa96b4a059f8ec01c5d044a87cd9dc7f3", null ],
    [ "bget4", "gzjoin_8c.html#aba9d03a69de5d40f265b48e14ba9c92e", null ],
    [ "bload", "gzjoin_8c.html#aa680d8f13a25b2a173f8a6a648b5d53b", null ],
    [ "bopen", "gzjoin_8c.html#a1057f62d6438f113a178837aae124b17", null ],
    [ "bskip", "gzjoin_8c.html#aeabcb42dde2c65eb1f29f998984ff02c", null ],
    [ "gzcopy", "gzjoin_8c.html#a79abcbc6637be647e768103de22ec599", null ],
    [ "gzhead", "gzjoin_8c.html#a77fdb382c48b884b0e3657c6ae1eb24b", null ],
    [ "gzinit", "gzjoin_8c.html#a245451f6c17c8bb8c10484e45f4918f5", null ],
    [ "main", "gzjoin_8c.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "put4", "gzjoin_8c.html#a7cea5ecfdb86820828381809cee72144", null ],
    [ "zpull", "gzjoin_8c.html#ac5d6f99beca691f34c343dc1885f2641", null ]
];