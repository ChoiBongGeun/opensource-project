var gzlog_8h =
[
    [ "gzlog", "gzlog_8h.html#a06e0b52f396bdf030c9b1ef1e20fbc0e", null ],
    [ "gzlog_close", "gzlog_8h.html#a7718114ae5bd3c6e7b53ea643d827315", null ],
    [ "gzlog_compress", "gzlog_8h.html#a45af64fc967dc0d83d66c91c5698b598", null ],
    [ "gzlog_open", "gzlog_8h.html#abb1427c5ea3ace896e07f824ba2ae1cb", null ],
    [ "gzlog_write", "gzlog_8h.html#a0dbb430ca6e7897f5ceef5b2379b4822", null ]
];