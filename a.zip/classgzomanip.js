var classgzomanip =
[
    [ "gzomanip", "classgzomanip.html#a62e624a4096f8d543472895936b80c13", null ],
    [ "operator<<", "classgzomanip.html#ace1e67eb789a4d1577a12cfcf782f22e", null ]
];