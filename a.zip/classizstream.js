var classizstream =
[
    [ "izstream", "classizstream.html#a87441c80bae3b9237d66f586e396d996", null ],
    [ "izstream", "classizstream.html#a9f958c2eef83729ec6dda0b800e48273", null ],
    [ "izstream", "classizstream.html#a30fb60b38cda7232e23b199c00e72412", null ],
    [ "~izstream", "classizstream.html#a55310a1de984e596df7b4236193ea1c3", null ],
    [ "close", "classizstream.html#ac2a7342deb79761277e846c8b24ef92a", null ],
    [ "error", "classizstream.html#a19ca9a17f897366d081aae3950f7946e", null ],
    [ "fp", "classizstream.html#a0438da66cc9cdb1a2a7ab4872a909fbf", null ],
    [ "open", "classizstream.html#a3e0af69bbc4704daa637850817b77098", null ],
    [ "open", "classizstream.html#a1ddcaff781f58a08576f0935be5ccd3c", null ],
    [ "read", "classizstream.html#a6e280a19c4a745ab4acc9615788ffa95", null ]
];